This PR (choose one or more, ✏️ delete others)

* changes documentation
* changes TypeScript definitions
* changes the public-facing API
* is a bug fix (closes #XXX)

Please include a summary in [README.md: Change Log: Unreleased](https://github.com/photonstorm/phaser-ce/blob/master/README.md#unreleased) and thank yourself.

Describe the changes below:
